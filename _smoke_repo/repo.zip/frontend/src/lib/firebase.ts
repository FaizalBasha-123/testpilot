export const firebaseConfig = {
  apiKey: "AIzaSyA1234567890EXAMPLEKEY",
  authDomain: "demo.firebaseapp.com"
};
